package mjc;

import mjc.ast.*;
import rs.etf.pp1.mj.runtime.*;
import rs.etf.pp1.symboltable.*;
import rs.etf.pp1.symboltable.concepts.*;

public class CodeGenerator extends VisitorAdaptor {

	/////////////////////////////////////////
	/** --------- _Expressions_ ---------- */
	/////////////////////////////////////////
	
	public void visit(ExprAdd e) {
		Addop a = e.getAddop();
		if (a instanceof AddopPlus) {
			Code.put(Code.add);
		}
		if (a instanceof AddopMinus) {
			Code.put(Code.sub);
		}
	}
	
	public void visit(ExprUminus e) {
		UnMinus um = e.getUnMinus();
		if (um instanceof UnMinusTrue) {
			Code.put(Code.sub);
		}
		
	}
	
	public void visit(UnMinusTrue u) {
		Code.loadConst(0);
	}
	
	/////////////////////////////////////////
	/** ------------ _Terms_ ------------- */
	/////////////////////////////////////////
	
	public void visit(MulopFactor t) {
		Mulop m = t.getMulop();
		if(m instanceof MulopMul) {
			Code.put(Code.mul);
		}
		if(m instanceof MulopDiv) {
			Code.put(Code.div);
		}
		if(m instanceof MulopMod) {
			Code.put(Code.rem);
		}
	}
	
	/////////////////////////////////////////
	/** ----------- _Factors_ ------------ */
	/////////////////////////////////////////
	
	public void visit(CasualDesigFact f) {
		
	}
	
	/////////////////////////////////////////
	/** --------- _Designators_ ---------- */
	/////////////////////////////////////////
	
	private Obj getPrevoiusDesigPart(Members m) {
		SyntaxNode parent = m.getParent();
		if(parent instanceof Members) {
			return ((Members)parent).obj;
		}
		else return null;
	}
	
	public void visit(DesignatorRef dr) {
		
	}
	
	public void visit(DesigField m) {
		Obj prev = getPrevoiusDesigPart(m);
		Obj curr = m.obj;
		if(prev == null) { System.out.println("Desig error"); return; } 
		if(prev.getType().getKind() != Struct.Class) { System.out.println("Not class desig error"); return; }
		
		
		switch(prev.getKind()) {
			case Obj.Var: case Obj.Fld: case Obj.Elem: Code.load(prev); break;
			default: System.out.println("Prev Desig error");
		}
		if(prev.getKind() == Obj.Var) 
			
		
		
	}
	
	public void visit(DesigElem m) {
		Obj prev = getPrevoiusDesigPart(m);
		Obj curr = m.obj;
		if(prev == null) System.out.println("Desig error");
		
		if(prev.getKind() == Obj.Var) 
			Code.load(prev);
		
	}
}
